"""
Copyright (c) Meta Platforms, Inc. and affiliates.

This source code is licensed under the MIT license found in the
LICENSE file in the root directory of this source tree.
"""
"""For backwards compatibility"""

from __future__ import annotations

if __name__ == "__main__":
    from fairchem.core._cli import main

    main()
