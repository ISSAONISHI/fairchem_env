python verify_correctness.py --path1 unittest/27998_vasprun.xml --path2 unittest/27998_faircluster_vasprun.xml --type xml
python verify_correctness.py --path1 unittest/27998_all.traj --path2 unittest/27998_faircluster_vasprun.xml --type traj
