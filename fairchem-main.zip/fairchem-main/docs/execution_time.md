# Notebook execution times

To help with debugging, we also provide the time to execute each of the notebooks in this repo on CPU. This should
give you an idea how long each one will take to run start-to-finish!

```{nb-exec-table}
```
