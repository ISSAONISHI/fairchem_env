# Technical presentations

To hear about some of the latest research directions for OCP, check out the following recorded presentations!

<iframe width="560" height="315" src="https://www.youtube.com/embed/xpgrV0t91AE?si=aNb10t6oongzCWrY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/6TunVLsj0YE?si=QA53hdLpq4DH5Nb_" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>