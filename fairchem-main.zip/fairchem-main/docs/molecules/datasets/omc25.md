# OMC25

The Open Molecular Crystals 2025 (OMC25) dataset was announced along with UMA, and comprises ~25 million calculations of organic molecular crystals from random packing of OE62 structures into various 3D unit cells. It is calculated at the PBE+D3 level of theory via VASP. More details and download information coming!
