# Why model atoms for climate?

New to chemistry but excited to know how ML can help? [Larry Zitnick](http://larryzitnick.org/) has made a few intro
videos for audiences without a computational chemistry background!

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?si=IDjebRSRSThxX7Ar&amp;list=PLU7acyFOb6DXgCTAi2TwKXaFD_i3C6hSL" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
