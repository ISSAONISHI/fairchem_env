A few miscellanous files can be found here. Their contents are as follows:
1. `her_candidates.csv`: a complete list of the potential HER catalysts found in this work
2. `cod_matches_lookup.pkl`: a lookup dictionary for COD materials. In some cases, the XRD data has matched to structures taken from COD. This file allows the lookup of a corresponding material in the computational pipeline if available.

If you were looking for the computational adsorption energy dataset, look [here](../)