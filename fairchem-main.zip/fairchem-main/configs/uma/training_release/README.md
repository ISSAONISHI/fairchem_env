# Documentation under construction...

## Local training
To test training locally on 1 GPU:
```python
fairchem -c configs/uma/training_release/uma_sm_direct_pretrain.yaml  cluster=h100_local dataset=uma_debug
```